package client;

import javafx.application.Application;
import javafx.stage.Stage;
import java.io.IOException;
import gui.ClientController;

public class ClientUI extends Application {
	private static ChatClient client;

	public static void main(String args[]) throws Exception {
		launch(args);
	} // end main

	@Override
	public void start(Stage primaryStage) throws Exception {
		ClientController aFrame = new ClientController(); // create StudentFrame
		try {
			client = new ChatClient("localhost", 5555, aFrame);
		} catch (IOException exception) {
			System.out.println("Error: Can't setup connection! Terminating client.");
			System.exit(1);
		}
		aFrame.start(primaryStage);
	}
	
	public static void sendShowAll() {
    	client.handleMessageFromClientUI("show all");
	}

	public static void updateMail(String who, String what) {
		client.handleMessageFromClientUI("update email " + who + " " + what);
	}
}
