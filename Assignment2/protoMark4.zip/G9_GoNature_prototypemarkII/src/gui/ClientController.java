package gui;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import client.*;
import common.Visitor;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ClientController implements Initializable{
	//private ChatClient client;
	public static int DEFAULT_PORT;
	
    @FXML
    private Button changeEmailBtn;

    @FXML
    private Button showAllBtn;

    @FXML
    private TextField changeMailUserID;

    @FXML
    private TextField changeMailNewEmail;

    @FXML
    private TableView<Visitor> visitorsTable;

    @FXML
    private TableColumn<Visitor, String> firstName;

    @FXML
    private TableColumn<Visitor, String> lastName;

    @FXML
    private TableColumn<Visitor, String> ID;

    @FXML
    private TableColumn<Visitor, String> Email;

    @FXML
    private TableColumn<Visitor, String> phoneNum;

    @FXML
    void showAll(ActionEvent event) {
    	visitorsTable.getItems().clear();
    	ClientUI.sendShowAll();
    	addData(ChatClient.getData());
    }

    @FXML
    void ChangeEmail(ActionEvent event) {
    	ClientUI.updateMail(changeMailUserID.getText(), changeMailNewEmail.getText());
    	if (ChatClient.getFeedback().equals("positive"))
    		showAll(event);
    	else
    		System.out.println("could not update email");
    }
    
	public void start(Stage primaryStage) throws Exception {	
		Parent root = FXMLLoader.load(getClass().getResource("/gui/client.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("GoNature Client");
		primaryStage.setScene(scene);
		primaryStage.show();	 	   
    }
	
	public void addData(ArrayList<ArrayList<String>> al) {
		for (ArrayList<String> arrayList : al) {
			addRow(arrayList);
		}
	}
	
	public void addRow(ArrayList<String> al) {
		visitorsTable.getItems().add(new Visitor(al));
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		firstName.setCellValueFactory(new PropertyValueFactory<Visitor,String>("firstName"));
		lastName.setCellValueFactory(new PropertyValueFactory<Visitor,String>("lastName"));
		ID.setCellValueFactory(new PropertyValueFactory<Visitor,String>("ID"));
		Email.setCellValueFactory(new PropertyValueFactory<Visitor,String>("email"));
		phoneNum.setCellValueFactory(new PropertyValueFactory<Visitor,String>("phoneNum"));

	}

}

