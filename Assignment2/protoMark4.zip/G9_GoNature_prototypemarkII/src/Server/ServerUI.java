package Server;

import javafx.application.Application;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import gui.ServerController;

public class ServerUI extends Application {
	final public static int DEFAULT_PORT = 5555;
	private static Connection con = null;
	private static boolean DBup = false;
	private static ServerController control;
	private static String msg;

	public static void main(String args[]) throws Exception {
		launch(args);
	} // end main

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		//ServerController aFrame = new ServerController(); // create StudentFrame
		
		control = new ServerController();
		control.start(primaryStage);
	}

	public static void runServer(EchoServer sv)
	{
		if (DBup) {
			sv.setCon(con);
	        try {
	          sv.listen(); //Start listening for connections
	        } catch (Exception ex) {
	        	setMsg("ERROR - Could not listen for clients!");
	        }
		}
		else {
			setMsg("Please Start DB first");
		}
		
	}

	public static void connectToDB(ArrayList<String> str) {
		String dburl = "jdbc:mysql://" + str.get(0) + ":" + str.get(1) + "/" + str.get(2) + "?serverTimezone=IST";
		String username = str.get(3);
		String password = str.get(4);
		try {
			con = DriverManager.getConnection(dburl, username, password);
			setMsg("DB " + str.get(2) + " Connected succsefuly on port " + str.get(1));
			DBup = true;
		} catch (SQLException e) {
			setMsg("could not connect to DB");
			e.printStackTrace();
		}
	}

	public static String getMsg() {
		String ret = msg;
		setMsg("");
		return ret;
	}

	public static void setMsg(String msg) {
		ServerUI.msg = msg;
	}

}
