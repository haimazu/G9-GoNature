package gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import client.*;
import common.Visitor;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ClientController implements Initializable{
	//private ChatClient client;
	public static int DEFAULT_PORT;
	
    @FXML
    private Button changeEmailBtn;

    @FXML
    private Button showAllBtn;

    @FXML
    private TextField changeMailUserID;

    @FXML
    private TextField changeMailNewEmail;

    @FXML
    private TableView<Visitor> visitorsTable;

    @FXML
    private TableColumn<Visitor, String> firstName;

    @FXML
    private TableColumn<Visitor, String> lastName;

    @FXML
    private TableColumn<Visitor, String> ID;

    @FXML
    private TableColumn<Visitor, String> Email;

    @FXML
    private TableColumn<Visitor, String> phoneNum;

    @FXML
    void showAll(ActionEvent event) {
    	visitorsTable.getItems().clear();
    	ClientUI.sendShowAll();
    	addData(ChatClient.getData());
    }

    @FXML
    void ChangeEmail(ActionEvent event) {
    	if(changeMailNewEmail.getText().equals("")||changeMailUserID.getText().equals("")) {
    		popUp("Error","Cannot Change Mail","you have to enter both id of the user you want to change and the new email.");
    	} else {
	    	ClientUI.updateMail(changeMailUserID.getText(), changeMailNewEmail.getText());
	    	if (ChatClient.getFeedback().equals("positive"))
	    		showAll(event);
	    	else {
	    		System.out.println("could not update email");
	    		popUp("Error","Email Not Updated","please check if the user ID exist in the table");
	    		}
	    	}
    	}
    
    
	public void start(Stage primaryStage) throws Exception {	
		Parent root = FXMLLoader.load(getClass().getResource("/gui/Client.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("GoNature Client");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent t) {
				ArrayList<String> byeBye = new ArrayList<String>();
				byeBye.add("disconn");
			//	ClientUI.getClient().handleMessageFromClientUI("disconn");
				try {
					ClientUI.getClient().sendToServer(byeBye);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Platform.exit();
				System.exit(0);
				System.out.println("client disconnected");
			}
		});
    }
	
	public void addData(ArrayList<ArrayList<String>> al) {
		for (ArrayList<String> arrayList : al) {
			addRow(arrayList);
		}
	}
	
	public void addRow(ArrayList<String> al) {
		visitorsTable.getItems().add(new Visitor(al));
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		firstName.setCellValueFactory(new PropertyValueFactory<Visitor,String>("firstName"));
		lastName.setCellValueFactory(new PropertyValueFactory<Visitor,String>("lastName"));
		ID.setCellValueFactory(new PropertyValueFactory<Visitor,String>("ID"));
		Email.setCellValueFactory(new PropertyValueFactory<Visitor,String>("email"));
		phoneNum.setCellValueFactory(new PropertyValueFactory<Visitor,String>("phoneNum"));

	}
	
	public void popUp(String title, String header, String content) { //popup for errors
		Alert alert = new Alert(Alert.AlertType.ERROR); //create alert
		alert.getDialogPane().setMaxSize(350, 150);
		alert.setTitle(title);
		alert.setHeaderText("");
		alert.setContentText(header+"\n"+content);
		alert.show(); //show alert
	}

}

