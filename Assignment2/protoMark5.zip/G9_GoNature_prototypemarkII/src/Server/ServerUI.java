package Server;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import gui.ServerController;

public class ServerUI extends Application {
	final public static int DEFAULT_PORT = 5555;
	private static Connection con2 = null;
	private static boolean DBup = false;
	private static boolean serverUP = false;
	private static ServerController control;
	private static String msg;
	private static EchoServer sv;

	public static void main(String args[]) throws Exception {
		launch(args);
	} 

	@Override
	public void start(Stage primaryStage) throws Exception {
		control = new ServerController();
		control.start(primaryStage);
	}

	public static void runServer(EchoServer sv)
	{
		if (DBup) {
			ServerUI.sv = sv;
			sv.setCon(con2);
	        try {
	          sv.listen();
	        } catch (Exception ex) {
	        	setMsg("ERROR - Could not listen for clients!");
	        }
	        serverUP=true;
		}
		else {
			setMsg("Please Start DB first");
		}
	}
	
	public static void stopServer() {
		try {
			sv.close();
			System.out.println("covefee");
		} catch (IOException e) {
			e.printStackTrace();
		}
		setMsg("Stoped Server succsefuly");
		serverUP=false;
	}


	public static void connectToDB(ArrayList<String> str) {
		String dburl = "jdbc:mysql://" + str.get(0) + ":" + str.get(1) + "/" + str.get(2) + "?serverTimezone=IST";
		String username = str.get(3);
		String password = str.get(4);
		try {
			con2 = DriverManager.getConnection(dburl, username, password);
			setMsg("DB " + str.get(2) + " Connected succsefuly on port " + str.get(1));
			DBup = true;
		} catch (SQLException e) {
			setMsg("could not connect to DB");
			e.printStackTrace();
		}
	}
	
	public static void disconnectFromDB() {
		if(serverUP) {
			setMsg("Please Stop server first");
		}
		else {
			try {
				con2.close();			
				if(con2.isClosed())
					System.out.println("closed");
			} catch (SQLException q) {
				q.printStackTrace();
			} catch (Exception e) {}
			setMsg("Disconected from DB succsefuly");
		}
	}

	public static String getMsg() {
		String ret = msg;
		setMsg("");
		return ret;
	}

	public static void setMsg(String msg) {
		ServerUI.msg = msg;
	}
	
	public static boolean isDBup() {
		return DBup;
	}

	public static boolean isServerUP() {
		return serverUP;
	}


}
