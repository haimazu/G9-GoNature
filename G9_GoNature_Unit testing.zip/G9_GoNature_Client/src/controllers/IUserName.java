package controllers;


public interface IUserName {

	public boolean checkLoginUserName();
}
