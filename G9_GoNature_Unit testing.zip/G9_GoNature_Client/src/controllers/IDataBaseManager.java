package controllers;

import java.util.ArrayList;

public interface IDataBaseManager {
	public void sendToServer(String caseName, ArrayList<String> date);
}
