package controllers;

public interface IAlert {
	
	public void failedAlert(String title, String msg);
}
