package controllers;



public interface IPassword {

	
	public boolean checkLoginPassword();
}
