package controllers;

public interface IEmpty {
	
	public boolean isEmptyFromSErver();
	
	public void setEmptyToChart(boolean isEmpty);
}
