// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 
package Server;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import gui.ServerController;
import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract superclass in order
 * to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */

public class EchoServer extends AbstractServer {
	private static Connection con;
	private static ServerController control;
	// Class variables *************************************************

	/**
	 * The default port to listen on.
	 */
	// final public static int DEFAULT_PORT = 5555;

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the echo server.
	 *
	 * @param port The port number to connect on.
	 * 
	 */

	public EchoServer(int port, Connection con, ServerController control) {
		super(port);
		EchoServer.con = con;
		EchoServer.control = control;
	}
	/**
	 * This method handles any messages received from the client.
	 *
	 * @param msg    The message received from the client.
	 * @param client The connection from which the message originated.
	 * @param
	 */
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		try {
			@SuppressWarnings("unchecked")
			ArrayList<String> command = (ArrayList<String>) msg;
			
			Statement stmt = con.createStatement();
			if (command.contains("select *")) {
				ResultSet rs = stmt.executeQuery("SELECT * FROM g9_gonatureprototype.visitor");
				ArrayList<ArrayList<String>> mega = new ArrayList<ArrayList<String>>();
				while (rs.next()) {
				//if (rs.next()) {
					ArrayList<String> res = new ArrayList<String>();
					//res.add("row");
					res.add(rs.getString(1));
					res.add(rs.getString(2));
					res.add(rs.getString(3));
					res.add(rs.getString(4));
					res.add(rs.getString(5));
					// this.sendToAllClients(msg);
					mega.add(res);
				}
					try {
						client.sendToClient(mega);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				rs.close();
			} else {
				PreparedStatement ps = con.prepareStatement("UPDATE g9_gonatureprototype.visitor SET email = ? WHERE (ID = ?)");
				System.out.println(command.get(0) + command.get(1));
				ps.setString(1, command.get(1));
				ps.setString(2, command.get(0));
				int lineChanged = ps.executeUpdate();
				try {
					if(lineChanged>0)
						client.sendToClient("updated email of "+command.get(0)+" to "+command.get(1));
					else
						client.sendToClient("error: could not update email");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ps.close();
			}
			sendToGui("Message received: " + command + " from " + client);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method overrides the one in the superclass. Called when the server
	 * starts listening for connections.
	 */
	protected void serverStarted() {
		sendToGui("GoNature Server listening to poteniatl clients at port " + this.getPort());
	}

	/**
	 * This method overrides the one in the superclass. Called when the server stops
	 * listening for connections.
	 */
	protected void serverStopped() {
		sendToGui("Server has stopped listening for connections.");
	}
	@Override
	protected void clientConnected(ConnectionToClient client) {
		sendToGui("New Client conneted: "+ client.toString() +" "+ this.getPort());
	}
	
	public static void sendToGui(String str) {
		control.logIt(str);
	}
	
	public void setCon(Connection con) {
		EchoServer.con = con;
	}
	
}