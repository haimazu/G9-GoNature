package common;

public enum Status {

	DepartmentManager,
	ParkManager,
	ServiceRepresentative,
	ParkWorker
}
