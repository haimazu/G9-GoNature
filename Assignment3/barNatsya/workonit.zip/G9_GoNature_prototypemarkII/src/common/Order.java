package common;

public interface Order {
	
	public void makeAnOrder();
	
	
}
